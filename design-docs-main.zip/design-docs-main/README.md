# Awesome Design Docs

A collection of design docs

- [English](https://github.com/charliesbot/design-docs/tree/main/english)
- [Spanish](https://github.com/charliesbot/design-docs/tree/main/spanish)
